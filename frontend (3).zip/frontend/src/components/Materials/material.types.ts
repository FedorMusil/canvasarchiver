import type { Change } from '@/src/api/change';

export type MaterialInputProps = {
    change: Change;
};
